class Link < ApplicationRecord
end
